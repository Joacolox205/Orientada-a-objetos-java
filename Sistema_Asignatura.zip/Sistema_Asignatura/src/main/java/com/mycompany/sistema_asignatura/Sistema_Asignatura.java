
package com.mycompany.sistema_asignatura;

/**
 *
 * @author Filito
 */
import java.util.Scanner;

public class Sistema_Asignatura {

    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);

        Estudiante estudiante1 = new Estudiante ("21.765.390-8","Filito",20,"25/01/2005");        
        Docente docente1 = new Docente("21.324.356-8","marcelo",21324,"21/04/2010","plaza norte");
        Asignatura asignatura1 = new Asignatura(312312, "Matematicas",estudiante1.getNombre(),docente1.getNombre(),0,0,0);
        
        System.out.println("ingrese su primera nota: ");
        double nota = input.nextDouble();
            
        System.out.println("ingrese su segunda nota: ");
        double nota2 = input.nextDouble();
                    
        System.out.println("ingrese su tercera nota: ");
        double nota3 = input.nextDouble();
                    
        asignatura1.setNota1(nota);
        asignatura1.setNota2(nota2);
        asignatura1.setNota3(nota3);
        
        if (asignatura1.calcularPromedio() > 4.0){
            System.out.println("usted aprobo la asignatura de " + asignatura1.getNombre() + " con nota final " + +asignatura1.calcularPromedio());
        }else{
            System.out.println("usted reprobado la asignatura de " + asignatura1.getNombre() + " con nota final " + +asignatura1.calcularPromedio());
        }
        
      }    
    }