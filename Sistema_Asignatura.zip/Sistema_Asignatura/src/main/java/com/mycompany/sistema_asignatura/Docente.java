/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_asignatura;

/**
 *
 * @author Filito
 */
public class Docente {
    private String rut;
    private String nombre;
    private int numdocente;
    private String fechaIngreso;
    private String sede;

    public Docente(String rut, int numdocente, String fechaIngreso, String sede) {
        this.rut = rut;
        this.numdocente = numdocente;
        this.fechaIngreso = fechaIngreso;
        this.sede = sede;
    }

    public Docente(String rut, String nombre, int numdocente, String fechaIngreso, String sede) {
        this.rut = rut;
        this.nombre = nombre;
        this.numdocente = numdocente;
        this.fechaIngreso = fechaIngreso;
        this.sede = sede;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public int getNumdocente() {
        return numdocente;
    }

    public void setNumdocente(int numdocente) {
        this.numdocente = numdocente;
    }

    public String getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public String getSede() {
        return sede;
    }

    public void setSede(String sede) {
        this.sede = sede;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }         
}
