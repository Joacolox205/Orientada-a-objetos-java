
package empresenvios;


public class Nacional extends Envio {
    
    private String regionEnvio;

    public Nacional() {
    }

    public Nacional(String regionEnvio, String codigo, double pesoKg) {
        super(codigo, pesoKg);
        this.regionEnvio = regionEnvio;
    }

    
    public String getRegionEnvio() {
        return regionEnvio;
    }

    
    
    
    @Override
    public double calcularenvio(){
        double costoEnvio = tarifaBase + (pesoKg * 500);
        return costoEnvio;
    }
    
    
    
    
}
