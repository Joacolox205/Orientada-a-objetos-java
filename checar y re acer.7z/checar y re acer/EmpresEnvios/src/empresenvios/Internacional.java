
package empresenvios;


public class Internacional extends Envio {
    
    private String paisEnvio;
    private double tazaImpuesto;

    public Internacional(String paisEnvio, double tazaImpuesto, String codigo, double pesoKg) {
        super(codigo, pesoKg);
        this.paisEnvio = paisEnvio;
        this.tazaImpuesto = tazaImpuesto;
    }

    public String getPaisEnvio() {
        return paisEnvio;
    }

    public double getTazaImpuesto() {
        return tazaImpuesto;
    }

    
    
    @Override
    public double calcularenvio(){
        double costoEnvio = tarifaBase + (pesoKg * 1500);
        double impuesto = costoEnvio * tazaImpuesto /100;
        costoEnvio = costoEnvio + impuesto;
        return costoEnvio;
    }
    
    
}
