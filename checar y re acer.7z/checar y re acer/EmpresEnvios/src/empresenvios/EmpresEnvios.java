
package empresenvios;

import java.util.Scanner;


public class EmpresEnvios {

    
    public static void main(String[] args) {
        
        Scanner imput = new Scanner(System.in);
        int opcion = 0;
        
        do{
            System.out.println("1.- Calcular envio nocional");
            System.out.println("2.- Calcular envio internacional");
            System.out.println("3.- salir");
            opcion=imput.nextInt();
            
            if(opcion==1){
                System.out.println("Calculo Envio Nacional");
                
                System.out.println("Region de Destino");
                String region =imput.next();
                
                System.out.println("Ingrese el codigo");
                String codigo =imput.next();
                
                System.out.println("Cuanto pesa el envio(kg");
                double peso =imput.nextDouble();
                
                Nacional envioNac = new Nacional(region, codigo, peso);
                
                System.out.println("Envio calculado");
                System.out.println("El precio por enviar es: $" + envioNac.calcularenvio());
                System.out.println("\n");
                
            }else if(opcion==2){
                System.out.println("Calculo Envio Internacional");
                
                System.out.println("Pais de Destino");
                String pais =imput.next();
                
                System.out.println("Taza de Impuesto");
                double impuesto =imput.nextDouble();
                
                System.out.println("Ingrese el codigo");
                String codigo =imput.next();
                
                System.out.println("Cuanto pesa el envio(kg");
                double peso =imput.nextDouble();
                
                Internacional envioInter = new Internacional(pais, impuesto, codigo, peso);
                
                System.out.println("Envio calculado");
                System.out.println("El precio por enviar es: $" + envioInter.calcularenvio());
                System.out.println("\n");
                
            }else if(opcion==3){
                System.out.println("Saliendo");
            }else System.out.println("Ingrese un numero valido");
            
            
            
            
            
        }while(opcion!=3);
        
        
        
        
        
        
        
    }
    
}
