
package empresenvios;


public abstract class Envio {
    
    private String codigo;
     double pesoKg;
     double tarifaBase = 2000;

    public Envio() {
    }

    public Envio(String codigo, double pesoKg) {
        this.codigo = codigo;
        this.pesoKg = pesoKg;
    }

    public String getCodigo() {
        return codigo;
    }

    public double getPesoKg() {
        return pesoKg;
    }

    public double getTarifaBase() {
        return tarifaBase;
    }

    

    
    
    public abstract double calcularenvio();
    
    
    
    
    
}
