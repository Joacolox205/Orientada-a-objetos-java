package concesionario;


public class Motocicleta extends Vehiculo {
    
    private int cilindrada;

    
    public Motocicleta(int cilindrada, String numeroChasis, String marca, double precioBase) {
        super(numeroChasis, marca, precioBase); 
        this.cilindrada = cilindrada;
    }

    
    @Override
    public double calcularPrecioFinal() {
        
        return getPrecioBase() * 1.15;
    }

    @Override
    public void mostrarFichaTecnica() {
        System.out.println("--- 🏍️ FICHA TÉCNICA: MOTOCICLETA ---");
        System.out.println("Marca: " + getMarca());
        System.out.println("Chasis: " + getNumeroChasis());
        System.out.println("Cilindrada: " + this.cilindrada + "cc");
        System.out.printf("Precio Final: $%,.0f\n", calcularPrecioFinal());
        System.out.println("-------------------------------------\n");
    }
}
