package concesionario;


public class Concesionario {

    public static void main(String[] args) {
        System.out.println("--- Sistema de Gestión de Concesionario ---");


        automovil autoElectrico = new automovil(4, "Eléctrico", "ABC12345", "Tesla", 30000000);

        
        Motocicleta moto = new Motocicleta(650, "DEF67890", "Honda", 8000000);

        
        
        autoElectrico.mostrarFichaTecnica();
        moto.mostrarFichaTecnica();

       
        double precioFinalAuto = autoElectrico.calcularPrecioFinal();
        double iva = precioFinalAuto * 0.19; 
        
        System.out.println("--- CÁLCULO DE IMPUESTOS ---");
        System.out.printf("El IVA para el automóvil %s es: $%,.0f\n", autoElectrico.getMarca(), iva);
    }
}
