package concesionario;


public abstract class Vehiculo {
    
    private String numeroChasis;
    private String marca;
    private double precioBase;

  
    public Vehiculo(String numeroChasis, String marca, double precioBase) {
        this.numeroChasis = numeroChasis;
        this.marca = marca;
        this.precioBase = precioBase;
    }

    
    public abstract double calcularPrecioFinal();


    public abstract void mostrarFichaTecnica();

    
    public String getNumeroChasis() {
        return numeroChasis;
    }

    public String getMarca() {
        return marca;
    }

    public double getPrecioBase() {
        return precioBase;
    }
}
