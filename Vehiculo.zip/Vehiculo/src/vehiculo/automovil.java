package concesionario;


public class automovil extends Vehiculo {
    // --- ATRIBUTOS PROPIOS ---
    private int numeroPuertas;
    private String tipoCombustible;

   
    public automovil(int numeroPuertas, String tipoCombustible, String numeroChasis, String marca, double precioBase) {
        
        super(numeroChasis, marca, precioBase);
        
        // 2. Inicializa sus propios atributos.
        this.numeroPuertas = numeroPuertas;
        this.tipoCombustible = tipoCombustible;
    }

    
    @Override
    public double calcularPrecioFinal() {
        double precioFinal = getPrecioBase(); 
        
        
        if (tipoCombustible.equalsIgnoreCase("Eléctrico")) {
            precioFinal += 1000000;
        } else {
            precioFinal += 500000;
        }
        return precioFinal; 
    }

    @Override
    public void mostrarFichaTecnica() {
        System.out.println("--- 🚗 FICHA TÉCNICA: AUTOMÓVIL ---");
        System.out.println("Marca: " + getMarca()); // Llama a un método heredado.
        System.out.println("Chasis: " + getNumeroChasis());
        System.out.println("Nº Puertas: " + this.numeroPuertas); // Usa un atributo propio.
        System.out.println("Combustible: " + this.tipoCombustible);
        // Llama a su propio método para el cálculo.
        // System.out.printf permite formatear el texto. "%,.0f" formatea el número con separadores de miles.
        System.out.printf("Precio Final: $%,.0f\n", calcularPrecioFinal());
        System.out.println("-------------------------------------\n");
    }
}
