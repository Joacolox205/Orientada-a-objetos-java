package tienda;

public class Electronico extends Producto {

    private String marca;
    private int mesesGarantia;

    public Electronico(String marca, int mesesGarantia, String id, String nombre, double precio) {
        super(id, nombre, precio);
        this.marca = marca;
        this.mesesGarantia = mesesGarantia;
    }

    
    public void extenderGarantia(int mesesExtendidos) {
        mesesGarantia += mesesExtendidos;
        System.out.println("Garantía extendida. Nueva duración: " + mesesGarantia + " meses.");
    }

    
    @Override
    public double calcularEnvio() {
        
        return 3.0 + (getPrecio() * 0.08);
    }

    
    @Override
    public void mostrarDetalle() {
        System.out.println("🔌 DETALLE DE ELECTRÓNICO");
        System.out.println("ID: " + getId());
        System.out.println("Nombre: " + getNombre());
        System.out.println("Marca: " + marca);
        System.out.println("Garantía: " + mesesGarantia + " meses");
        System.out.println("Precio: $" + getPrecio());
        System.out.printf("Costo de envío: $%.2f\n", calcularEnvio());
        System.out.println("----------------------------\n");
    }

    // Getters
    public String getMarca() {
        return marca;
    }

    public int getMesesGarantia() {
        return mesesGarantia;
    }
}


