package tienda;

import java.util.ArrayList;
import java.util.List;

public class Cliente {

    private String id;
    private String nombre;
    private List<Pedido> pedidosRealizados;

    public Cliente(String id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        pedidosRealizados = new ArrayList<>();
    }
    
    public void realizarPedido(Pedido pedido){
        pedidosRealizados.add(pedido);
    }
    
    
    
}
