package tienda;

public class Ropa extends Producto {

    private String talla;
    private String color;

    public Ropa(String talla, String color, String id, String nombre, double precio) {
        super(id, nombre, precio);
        this.talla = talla;
        this.color = color;
    }

    // Implementación obligatoria del método abstracto
    @Override
    public double calcularEnvio() {
        // Ejemplo: tarifa base + tarifa por prenda
        return 2.0 + (getPrecio() * 0.05);
    }

    // Implementación obligatoria del método abstracto
    @Override
    public void mostrarDetalle() {
        System.out.println("👕 DETALLE DE ROPA");
        System.out.println("ID: " + getId());
        System.out.println("Nombre: " + getNombre());
        System.out.println("Precio: $" + getPrecio());
        System.out.println("Talla: " + talla);
        System.out.println("Color: " + color);
        System.out.printf("Costo de envío: $%.2f\n", calcularEnvio());
        System.out.println("----------------------------\n");
    }

    public void ajustarTalla(String nuevaTalla) {
        System.out.println("Talla ajustada de " + talla + " a " + nuevaTalla);
        this.talla = nuevaTalla;
    }

    public String getTalla() {
        return talla;
    }

    public String getColor() {
        return color;
    }
}

