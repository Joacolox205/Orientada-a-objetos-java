package tienda;


public class Libro extends Producto {
    
    // Atributos propios de un Libro
    private String autor;
    private int paginas;

    // Constructor: Recibe los datos propios y los datos del padre (Producto)
    public Libro(String autor, int paginas, String id, String nombre, double precio) {
        super(id, nombre, precio); // Llama al constructor de Producto
        this.autor = autor;
        this.paginas = paginas;
    }

   
    @Override
    public double calcularEnvio() {
        // Lógica de ejemplo: El envío de libros es una tarifa plana
        return 5.0; 
    }

    // 2. OBLIGATORIO: Implementar mostrarDetalle()
    @Override
    public void mostrarDetalle() {
        // Usa los getters heredados de Producto
        System.out.println("--- DETALLE DE LIBRO ---");
        System.out.println("ID: " + getId() + " | Nombre: " + getNombre() + " | Precio: " + getPrecio() + "€");
        System.out.println("Autor: " + autor + " | Páginas: " + paginas);
        // La línea de abajo usa printf para formatear la salida con dos decimales (%.2f)
        System.out.printf("Costo de envío: %.2f€\n", calcularEnvio());
    }
    
    // --- Getters propios ---
    
    public String getAutor() {
        return autor;
    }

    public int getPaginas() {
        return paginas;
    }
}

