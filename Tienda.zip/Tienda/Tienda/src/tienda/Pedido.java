package tienda;

import java.util.ArrayList;
import java.util.List;

public class Pedido {
    
    private List<Producto> listaProductos;
    private double total;

    public Pedido() {
        this.listaProductos = new ArrayList<>();
        total = 0;  
    }
    
    public void agregarProducto(Producto prod){
        listaProductos.add(prod);
        System.out.println("Producto agregado al pedido");
    }
    
    public void calcularTotal(){
        for(Producto pro : listaProductos){
            total = total + pro.getPrecio();
        }
    }
    
}
