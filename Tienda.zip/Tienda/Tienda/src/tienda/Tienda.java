package tienda;

public class Tienda {
    public static void main(String[] args) {
        // Crear una prenda de ropa con todos los atributos básicos
        Ropa chaqueta = new Ropa("L", "Negro", "R003", "Chaqueta Impermeable", 39.99);

        // Mostrar detalles iniciales
        System.out.println("🛍️ Bienvenido a la Tienda Virtual\n");
        chaqueta.mostrarDetalle();

        // Ajustar la talla
        chaqueta.ajustarTalla("XL");

        // Mostrar detalles actualizados
        chaqueta.mostrarDetalle();

        // Calcular y mostrar precio con descuento
        double descuento = 15.0; // 15% de descuento
        double precioFinal = chaqueta.calcularDescuento(descuento);
        System.out.printf("💸 Precio con %.0f%% de descuento: $%.2f\n", descuento, precioFinal);

        // Mostrar costo total incluyendo envío
        double totalConEnvio = precioFinal + chaqueta.calcularEnvio();
        System.out.printf("🚚 Total con envío incluido: $%.2f\n", totalConEnvio);
    }
}

