
package gestiondeempleados;

public interface BonusCalculable {
    
    double calcularBonus();
}
